/*
 * Group 1: Computer Service Support System (24)
 */
package User.CustomerGUI;

import ExceptionHandling.MyException;
import User.Customer;
import UserInfo.Order;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;

/**
 *
 * @author Ash
 */
public class ValidateOrder {
    Connection conncat = null;
    java.sql.Statement stcat = null;
    ResultSet rs = null;
    String query;
    private Customer c;
    private Order o;
    private Order tempOrder = null;
    public ValidateOrder() throws SQLException {
        this.c = new Customer();
    }
    
    public ValidateOrder(Customer c) throws SQLException {
        this.c = c;
        conncat = DriverManager.getConnection("jdbc:derby://localhost:1527/ComputerServiceSupportSystem","csss","csss");
    }
    public Order getOrder(String id, int custID) throws SQLException{
        query = "SELECT CUSTOMERID,TECHNICIANID,STATUS,PRICE,COMPUTERPART FROM ORDERS where ORDERID="+id;
        rs = stcat.executeQuery(query);
        rs.first();
        int cust = rs.getInt("CUSTOMERID");
        if(cust != custID){
            return tempOrder;
        }else{
            tempOrder.setPrice(rs.getInt("PRICE"));
            tempOrder.setStatus(rs.getString("STATUS"));
            tempOrder.setComputerPart(rs.getString("COMPUTERPART"));
            tempOrder.setTehnicianID(rs.getInt("TECHNICIANID"));
            return tempOrder;
        }
    }
    public String cancelOrder(String id, int custID) throws SQLException{
        String sqlOrderCust = "SELECT ORDERID,CUSTOMERID,STATUS FROM ORDERS WHERE ORDERID="+id;
        rs = stcat.executeQuery(sqlOrderCust);
        rs.first();
        int retrivedCust = rs.getInt("CUSTOMERID");
        String status = rs.getString("STATUS");
        if(status != "Processing"){
            if(retrivedCust != custID){
                return "This order doesn't belong to you";
            }else{
                query = "DELETE FROM PERSON WHERE ORDERID="+id;
                return "Order with id " + id + " got deleted succesffuly";
            }
        }else{
            return "This Order couldn't be canceled in "+ status +" status";
        }
    }
    public int checkPartAvailability(String part) throws MyException, SQLException {
        if (part.equals(""))
            throw new MyException("Can't leave this field empty!");
        else {
            int price = c.searchParts(part);
            if (price == -1) {
                throw new MyException("Part not found");
            } else {
                return price;
            }
        }
    }
    
    String createOrder(int customerId, String part, int partPrice) throws SQLException { //note: here we could've ommitted the customerId param., as the Customer object already has a pid
        int orderId = c.createOrder(customerId, part, partPrice);
        int technicianId = o.assignToTechnician(orderId);
        if (technicianId == -1) {
            return "Order created successfully!\nHowever, all technicians are currently working on other orders.\nTherefore, order status is \"Processing\" until a technician is found";
        } else {
            return "Order created successfully!\nAssigning your order to technician with id: " + technicianId;
        }
    }
    
    public Customer getCustomer() {
        return c;
    }
    public void setCustomer(Customer c) {
        this.c = c;
    }
    
    public String getName() {
        return c.getName();
    }
    public int getPid() {
        return c.getPid();
    }
}
