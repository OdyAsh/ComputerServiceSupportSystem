/*
 * Group 1: Computer Service Support System (24)
 */
package User;

import UserInfo.Order;
import java.time.LocalDate;
import java.util.ArrayList;

/**
 *
 * @author infolos
 */
public class AdminControler {
    private Admin currentAdmin;
    private ArrayList<Order> tempOrd = null;
    public AdminControler(Admin currentAdmin) {
        this.currentAdmin = currentAdmin;
    }
    public ArrayList<Order> getTempOrders() {
        return tempOrd;
    }

    public void setTempOrders(LocalDate date,String Status) {
        tempOrd = this.getCurrentAdmin().generateReport(date, Status);
    }
    

    public Admin getCurrentAdmin() {
        return currentAdmin;
    }

    public void setCurrentAdmin(Admin currentAdmin) {
        this.currentAdmin = currentAdmin;
    }
    public String getName(){
        return currentAdmin.getName();
    }
    public String getAddress(){
        return currentAdmin.getAddress();
    }
    public int getPersonId(){
        return currentAdmin.getPID();
    }
    public String getUserName(){
        return currentAdmin.getUserName();
    }
    public String getEmail(){
        return currentAdmin.getEmail();
    }
    public String getPassword(){
        return currentAdmin.getPassword();
    }
}
